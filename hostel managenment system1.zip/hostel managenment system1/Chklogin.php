<?php

$host="localhost"; // Host name
$username="root"; // username
$password="root"; // password
$db_name="TA"; // Database name
$tbl_name="user"; // Table name

mysql_connect("$host", "$username", "$password");
mysql_select_db("$db_name");


$myusername=mysql_real_escape_string($_POST['username']);
$mypassword=mysql_real_escape_string($_POST['password']);

$sql="SELECT * FROM $tbl_name WHERE username='$myusername' and password='$mypassword'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);
if($count==1){
  // Register $myusername, $mypassword and redirect to file "login_success.php"
  session_start();
  $_SESSION['username'] = $myusername;
  $_SESSION['password'] = $mypassword; 
  header("location: login_success.php");
} 
    else {
        echo "Wrong Username or Password";
}

?>


